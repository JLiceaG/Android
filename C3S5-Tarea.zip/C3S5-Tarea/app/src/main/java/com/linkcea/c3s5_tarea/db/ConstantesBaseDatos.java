package com.linkcea.c3s5_tarea.db;


public final class ConstantesBaseDatos {

    public static final String DATABASE_NAME = "petdb";
    public static final int DATABASE_VERSION = 1;

    public static final String DATABASE_TABLE_MASCOTA = "pet";
    public static final String DATABASE_TABLE_MASCOTA_ID = "id_pet";
    public static final String DATABASE_TABLE_MASCOTA_NAME = "nombre";

    public static final String DATABASE_TABLE_FOTO = "foto";
    public static final String DATABASE_TABLE_FOTO_ID = "id_foto";
    public static final String DATABASE_TABLE_FOTO_IDMASCOTA = "id_pet";
    public static final String DATABASE_TABLE_FOTO_DIRFOTO = "foto";

    public static final String DATABASE_TABLE_LIKEFOTO = "like_foto";
    public static final String DATABASE_TABLE_LIKEFOTO_ID = "id_likefoto";
    public static final String DATABASE_TABLE_LIKEFOTO_NUMLIKES = "numero_likes";
}
