package com.linkcea.c3s5_tarea.rewarded;

import android.app.Activity;

import com.linkcea.c3s5_tarea.pojo.Pet;
import com.linkcea.c3s5_tarea.adapter.PetAdapter;

import java.util.ArrayList;

public interface IPetRewardedView {

    public void generarLayoutManager();

    public PetAdapter crearAdaptador(ArrayList<Pet> listContactos, Activity activity);

    public void inicializarAdaptador(PetAdapter petAdapter);

    public boolean isEmptyRV(ArrayList<Pet> listMascotasLike);
}
