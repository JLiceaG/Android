package com.linkcea.c3s5_tarea.fragment;

import android.app.Activity;

import com.linkcea.c3s5_tarea.adapter.PetAdapter;
import com.linkcea.c3s5_tarea.pojo.Pet;

import java.util.ArrayList;

public interface IViewPetsFragment {

    public void generarLayoutManager();

    public PetAdapter crearAdaptador(ArrayList<Pet> listMascotas, Activity activity);

    public void inicializarAdaptador(PetAdapter petAdapter);
}
