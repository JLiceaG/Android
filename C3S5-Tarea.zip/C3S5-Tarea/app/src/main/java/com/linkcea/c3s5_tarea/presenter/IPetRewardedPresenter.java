package com.linkcea.c3s5_tarea.presenter;

public interface IPetRewardedPresenter {
    public void obtenerMascotas();
    public void mostrarMascotasRV();
}
