package com.linkcea.c3s5_tarea.presenter;

public interface IPetPresenter {

    public void obtenerMascotas();
    public void mostrarMascotasRV();

}
