package com.linkcea.c4s2_tarea;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v7.widget.Toolbar;


import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.adapter.PageAdapter;
import com.linkcea.c4s2_tarea.fragment.PerfilFragment;
import com.linkcea.c4s2_tarea.fragment.RecyclerViewFragment;
import com.linkcea.c4s2_tarea.menu_opciones.AcercaDe;
import com.linkcea.c4s2_tarea.menu_opciones.Configurar;
import com.linkcea.c4s2_tarea.menu_opciones.Contacto;
import com.linkcea.c4s2_tarea.menu_opciones.Maps;
import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.rewarded.Rewarded;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    private ArrayList<Pet> favPets;


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_opciones, menu);

        MenuItem actionMenuItem = menu.findItem(R.id.menu_fav_history);
        actionMenuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Intent intent = new Intent(MainActivity.this, Rewarded.class);
                intent.putParcelableArrayListExtra("favoritos", favPets);
                startActivity(intent);
                return false;
            }
        });

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.mContacto:
                Intent intent = new Intent(this, Contacto.class);
                startActivity(intent);
                break;

            case R.id.mAcercaDe:
                Intent i = new Intent(this, AcercaDe.class);
                startActivity(i);
                break;

            case R.id.mConfigurar:
                Intent in = new Intent(this, Configurar.class);
                startActivity(in);
                break;

            case R.id.mMapas:
                Intent inte = new Intent(this, Maps.class);
                startActivity(inte);
                break;

            case R.id.menu_fav_history:
                Intent inten = new Intent(this, Rewarded.class);
                //inte.putParcelableArrayListExtra("favoritos", favPets);
                startActivity(inten);
                break;

        }

        return super.onOptionsItemSelected(item);
    }


    public void configure_toolbar()
    {
        Toolbar abActionBar = (Toolbar) findViewById(R.id.abActionBar);
        setSupportActionBar(abActionBar);
        getSupportActionBar().setIcon(R.drawable.icons8_huellagato);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.abActionBar);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        setUpViewPager();

        configure_toolbar();

        if (toolbar !=null){
            setSupportActionBar(toolbar);
        }

    }

    //Agrear la lista a fragments
    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(new RecyclerViewFragment());
        fragments.add(new PerfilFragment());

        return fragments;
    }

    private void setUpViewPager(){
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(), agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.contactopet);
        tabLayout.getTabAt(1).setIcon(R.drawable.about);
    }

}

