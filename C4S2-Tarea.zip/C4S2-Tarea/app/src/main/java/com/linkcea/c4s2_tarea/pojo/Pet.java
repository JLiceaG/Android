package com.linkcea.c4s2_tarea.pojo;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Pet implements Parcelable{

    private int id;
    private String name;
    private int bonies;//score or likes
    private int picture;

    private ArrayList<PetFoto> galeria;

    public Pet (String name) {
        this.name = name;
    }

    public Pet(int picture, String name, int bonies) {
        this.name = name;
        this.bonies = bonies;
        this.picture = picture;
    }

    public Pet(int picture, String name) {
        this.picture = picture;
        this.name = name;
        this.bonies = 0;
    }

    protected Pet(Parcel in){
        this.name = in.readString();
        this.bonies = in.readInt();
        this.picture = in.readInt();
    }

    public Pet() {
        this.galeria = new ArrayList<>();
    }

    public static final Creator<Pet> CREATOR = new Creator<Pet>() {
        @Override
        public Pet createFromParcel(Parcel in) {
            return new Pet(in);
        }

        @Override
        public Pet[] newArray(int size) {
            return new Pet[size];
        }
    };

    public ArrayList<PetFoto> getGaleria() {
        return galeria;
    }

    public void setGaleria(ArrayList<PetFoto> galeria) {
        this.galeria = galeria;
    }

    public void simulacionLike(){
        this.bonies = this.bonies + 1 ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBonies() {
        return bonies;
    }

    public void setBonies(int bonnies) {
        this.bonies = bonnies;
    }

    public int getPicture() {
        return picture;
    }

    public void setPicture(int picture) {
        this.picture = picture;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(bonies);
        dest.writeInt(picture);
    }

    public void addFoto(PetFoto petFoto){
        galeria.add(petFoto);
    }

}
