package com.linkcea.c4s2_tarea.fragment;

import android.app.Activity;

import com.linkcea.c4s2_tarea.adapter.PetAdapter;
import com.linkcea.c4s2_tarea.pojo.Pet;

import java.util.ArrayList;

public interface IViewPetsFragment {

    public void generarLayoutManager();

    public PetAdapter crearAdaptador(ArrayList<Pet> listMascotas, Activity activity);

    public void inicializarAdaptador(PetAdapter petAdapter);
}
