package com.linkcea.c4s2_tarea.presenter;

public interface IPetRewardedPresenter {
    public void obtenerMascotas();
    public void mostrarMascotasRV();
}
