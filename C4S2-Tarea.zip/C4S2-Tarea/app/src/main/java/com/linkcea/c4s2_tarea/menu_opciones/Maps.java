package com.linkcea.c4s2_tarea.menu_opciones;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;

import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.MapsActivity;

public class Maps extends AppCompatActivity {

    public void configure_toolbar()
    {
        Toolbar abActionBar = (Toolbar) findViewById(R.id.abActionBar);
        setSupportActionBar(abActionBar);
        getSupportActionBar().setIcon(R.drawable.icons8_huellagato);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_mapas);

        configure_toolbar();

        ImageButton btn1 = findViewById(R.id.imgBtn1);
        ImageButton btn2 = findViewById(R.id.imgBtn2);
        ImageButton btn3 = findViewById(R.id.imgBtn3);
        ImageButton btn4 = findViewById(R.id.imgBtn4);
        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(Maps.this, MapsActivity.class);
                String latitud;
                String longitud;
                latitud = "25.6563433415746";
                longitud = "-100.25442838668825";
                i.putExtra(getResources().getString(R.string.latitud),latitud);
                i.putExtra(getResources().getString(R.string.longitud),longitud);
                startActivity(i);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(Maps.this, MapsActivity.class);
                String latitud;
                String longitud;
                latitud = "25.653132509784722";
                longitud = "-100.449435710907";
                i.putExtra(getResources().getString(R.string.latitud),latitud);
                i.putExtra(getResources().getString(R.string.longitud),longitud);
                startActivity(i);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(Maps.this, MapsActivity.class);
                String latitud;
                String longitud;
                latitud = "25.719942534266753";
                longitud = "-100.21914124488832";
                i.putExtra(getResources().getString(R.string.latitud),latitud);
                i.putExtra(getResources().getString(R.string.longitud),longitud);
                startActivity(i);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(Maps.this, MapsActivity.class);
                String latitud;
                String longitud;
                latitud = "25.644660141220303";
                longitud = "-100.32747030258179";
                i.putExtra(getResources().getString(R.string.latitud),latitud);
                i.putExtra(getResources().getString(R.string.longitud),longitud);
                startActivity(i);
            }
        });
    }


}
