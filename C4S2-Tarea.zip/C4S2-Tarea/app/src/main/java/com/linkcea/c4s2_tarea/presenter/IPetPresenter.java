package com.linkcea.c4s2_tarea.presenter;

public interface IPetPresenter {

    public void obtenerMascotas();
    public void mostrarMascotasRV();

}
