package com.linkcea.c4s2_tarea.restApi.restAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.linkcea.c4s2_tarea.restApi.ConstantesRestApi;
import com.linkcea.c4s2_tarea.restApi.EndpointsApi;
import com.linkcea.c4s2_tarea.restApi.restDeserializador.PetDeserializador;
import com.linkcea.c4s2_tarea.restApi.restmodel.PetResponse;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestApiAdapter {

    public EndpointsApi establecerConexionRestApiInstagram(Gson gson){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstantesRestApi.URL_BASE)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        return retrofit.create(EndpointsApi.class);
    }

    public Gson construirGsonDeserializadorMediaRecent(){
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(PetResponse.class, new PetDeserializador());
        return gsonBuilder.create();
    }

}
