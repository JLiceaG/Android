package com.linkcea.c4s2_tarea.fragment;

import com.linkcea.c4s2_tarea.adapter.PetProfileAdapter;
import com.linkcea.c4s2_tarea.pojo.PetApi;

import java.util.ArrayList;

public interface IViewPetProfileFragment {

    public void generarGridLayout();

    public PetProfileAdapter crearAdaptador(ArrayList<PetApi> pets);

    public void inicializarAdaptadorRV(PetProfileAdapter adaptador);

}
