package com.linkcea.c4s2_tarea.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.pojo.PetFoto;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {

    private Context context;

    public BaseDatos(Context context) {
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        String queryCrearTablaMascota = "CREATE TABLE " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA
                + "("
                + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME + " TEXT "
                + ")";

        String queryCrearTablaFoto = "CREATE TABLE " + ConstantesBaseDatos.DATABASE_TABLE_FOTO
                +"("
                + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID + " INTEGER, "
                + ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO + " INTEGER, "
                + " FOREIGN KEY (" + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID + ") "
                + " REFERENCES " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA
                + "(" + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID + ")"
                +")";

        String queryCrearTablaLikeFoto = "CREATE TABLE " + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO
                +"("
                + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID + " INTEGER, "
                + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO_NUMLIKES + " INTEGER, "
                + " FOREIGN KEY (" + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID + ") "
                + " REFERENCES " + ConstantesBaseDatos.DATABASE_TABLE_FOTO
                + "(" + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID + ")"
                +")";

        db.execSQL(queryCrearTablaMascota);
        db.execSQL(queryCrearTablaFoto);
        db.execSQL(queryCrearTablaLikeFoto);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA);
        db.execSQL("DROP TABLE IF EXISTS " + ConstantesBaseDatos.DATABASE_TABLE_FOTO);
        db.execSQL("DROP TABLE IF EXISTS " + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO);
        onCreate(db);
    }


    public ArrayList<Pet> obtenerMascotas(){
        ArrayList<Pet> listMascotas = new ArrayList<>();
        String query = "SELECT * FROM " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()){
            Pet pet = new Pet();
            ArrayList<PetFoto> listMascotaFoto = new ArrayList<>();
            pet.setId(registros.getInt(0));
            pet.setName(registros.getString(1));

            String queryFoto = "SELECT * FROM " + ConstantesBaseDatos.DATABASE_TABLE_FOTO
                    + " WHERE " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID
                    + "=" + pet.getId();

            Cursor registrosFotos = db.rawQuery(queryFoto, null);
            if(registrosFotos.moveToNext()){
                PetFoto petFoto = new PetFoto();
                petFoto.setIdMascotaFoto(registrosFotos.getInt(0));
                petFoto.setIdMascota(registrosFotos.getInt(1));
                petFoto.setPet(pet);
                petFoto.setIdFoto(registrosFotos.getInt(2));
                listMascotaFoto.add(petFoto);
            }else {
                //nothing
            }
            pet.setGaleria(listMascotaFoto);
            listMascotas.add(pet);
        }

        db.close();
        return listMascotas;
    }


    public void insertarMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA, null, contentValues);
        db.close();
    }

    public void insertarFoto(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.DATABASE_TABLE_FOTO, null, contentValues);
        db.close();
    }

    public void insertarLikeFoto(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO, null, contentValues);
        db.close();
    }

    public ArrayList<Pet> obtenerMascotasLikeadas(){
        ArrayList<Pet> listMascotasLikeadas = new ArrayList<>();
        //PONEMOS LIMITE DE 5 PORQUE SON LAS QUE SE REQUIEREN
        String query = "SELECT DISTINCT " + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID
                + " FROM " + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO
                + " ORDER BY " + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO_ID
                + " DESC LIMIT 5";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);
        while (registros.moveToNext()){
            int idMascotaFoto = registros.getInt(0);
            Pet pet = new Pet();
            String queryMascotaFoto = "SELECT * FROM " + ConstantesBaseDatos.DATABASE_TABLE_FOTO
                    + " INNER JOIN " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA
                    +" on " + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA + "." + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID
                    + "=" + ConstantesBaseDatos.DATABASE_TABLE_FOTO + "." + ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID
                    + " WHERE " + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID
                    + " = " + idMascotaFoto
                    ;
            Cursor registrosMascotaFoto = db.rawQuery(queryMascotaFoto, null);
            if (registrosMascotaFoto.moveToNext()){
                pet.setId(registrosMascotaFoto.getInt(3));
                pet.setName(registrosMascotaFoto.getString(4));
                PetFoto petFoto  = new PetFoto();
                petFoto.setIdMascotaFoto(registrosMascotaFoto.getInt(0));
                petFoto.setIdMascota(registrosMascotaFoto.getInt(1));
                petFoto.setIdFoto(registrosMascotaFoto.getInt(2));
                pet.addFoto(petFoto);
            }
            listMascotasLikeadas.add(pet);
        }
        db.close();
        return listMascotasLikeadas;
    }

    public int obtenerLikeMascotaFoto(PetFoto petFoto){
        int likes = 0;
        String query = "SELECT COUNT(" + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO_NUMLIKES+")"
                + " FROM " + ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO
                + " WHERE " + ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID
                + "=" + petFoto.getIdMascotaFoto();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);
        while (registros.moveToNext()){
            likes = registros.getInt(0);
        }
        db.close();
        return likes;
    }
}
