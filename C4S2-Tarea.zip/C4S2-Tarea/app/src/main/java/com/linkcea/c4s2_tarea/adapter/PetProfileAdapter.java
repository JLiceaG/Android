package com.linkcea.c4s2_tarea.adapter;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.linkcea.c4s2_tarea.DetallePet;
import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.pojo.PetApi;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PetProfileAdapter extends RecyclerView.Adapter<PetProfileAdapter.PetProfileViewHolder> {

    ArrayList<PetApi> pets;
    Activity activity;

    public PetProfileAdapter(ArrayList<PetApi> pets, Activity activity) {
        this.pets= pets;
        this.activity = activity;
    }

    @Override
    public PetProfileViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_profile_pets, parent, false);

        return new PetProfileViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PetProfileViewHolder petProfileViewHolder, int position) {
        final PetApi pet = pets.get(position);
        Picasso.with(activity)
                .load(pet.getUrlFoto())
                .placeholder(R.drawable.master_sword_ocarina_of_time)
                .into(petProfileViewHolder.imgFoto);
        petProfileViewHolder.tvLikes.setText(String.valueOf(pet.getLikes()));

        petProfileViewHolder.imgFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, DetallePet.class);
                intent.putExtra("url", pet.getUrlFoto());
                intent.putExtra("like", pet.getLikes());
                activity.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    public static class PetProfileViewHolder extends RecyclerView.ViewHolder {

        private ImageView imgFoto;
        private TextView tvLikes;

        public PetProfileViewHolder(View itemView) {
            super(itemView);

            imgFoto     = (ImageView) itemView.findViewById(R.id.ivPetPicture);
            tvLikes     = (TextView) itemView.findViewById(R.id.tvLikes);

        }
    }
}
