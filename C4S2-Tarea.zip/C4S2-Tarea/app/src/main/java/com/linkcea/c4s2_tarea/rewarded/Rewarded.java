package com.linkcea.c4s2_tarea.rewarded;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.adapter.PetAdapter;
import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.presenter.IPetRewardedPresenter;
import com.linkcea.c4s2_tarea.presenter.PetRewardedPresenter;

import java.util.ArrayList;

public class Rewarded extends AppCompatActivity implements IPetRewardedView {

    public void configure_toolbar()
    {
        Toolbar abActionBar = (Toolbar) findViewById(R.id.abActionBar);
        setSupportActionBar(abActionBar);
        getSupportActionBar().setIcon(R.drawable.icons8_huellagato);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private RecyclerView petRewardedRecyclerView;
    private PetAdapter petAdapter;
    private TextView tvCountLikes;
    private TextView tvEmpty;
    private IPetRewardedPresenter iPetRewardedPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewarded);

        configure_toolbar();

        Intent intent = getIntent();
        //listMascotasLike            = intent.getParcelableArrayListExtra(getResources().getString(R.string.pArrayListMascotasRewarded));
        petRewardedRecyclerView    = (RecyclerView) findViewById(R.id.rvRewarded);
        tvEmpty = (TextView) findViewById(R.id.cv_tv_emptymessage);
        //txvCountLikes = (TextView) findViewById(R.id.actionbar_txv_countlikes);
        //txvCountLikes.setVisibility(View.INVISIBLE);
        iPetRewardedPresenter = new PetRewardedPresenter(this, this.getApplicationContext(), this);
    }

    private void inicializarAdaptador(){
        petRewardedRecyclerView.setAdapter(petAdapter);
    }

    @Override
    public void generarLayoutManager() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        petRewardedRecyclerView.setLayoutManager(linearLayoutManager);
    }

    @Override
    public PetAdapter crearAdaptador(ArrayList<Pet> listMascotasLike, Activity activity) {
        if(listMascotasLike.isEmpty()){
            Log.w("Lista Adaptador", "Vacio");
        }else {
            Log.w("Lista Adaptador", "Lleno con" + listMascotasLike.get(0).getName());
        }
        petAdapter = new PetAdapter(listMascotasLike,this, false);
        return petAdapter;
    }

    @Override
    public void inicializarAdaptador(PetAdapter petAdapter) {
        petRewardedRecyclerView.setAdapter(petAdapter);
    }

    @Override
    public boolean isEmptyRV(ArrayList<Pet> listMascotasLike) {
        if(listMascotasLike.isEmpty()){
            petRewardedRecyclerView.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
            return true;
        }else {
            petRewardedRecyclerView.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            return false;
        }
    }

}
