package com.linkcea.c4s2_tarea.menu_opciones;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.linkcea.c4s2_tarea.MainActivity;
import com.linkcea.c4s2_tarea.R;

public class Configurar extends AppCompatActivity {
    public void configure_toolbar()
    {
        Toolbar abActionBar = (Toolbar) findViewById(R.id.abActionBar);
        setSupportActionBar(abActionBar);
        getSupportActionBar().setIcon(R.drawable.icons8_huellagato);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_configurar);

        configure_toolbar();

        Button botonAccess = findViewById(R.id.btnGuardarAccess);
        botonAccess.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v){
                EditText txtAcces = (EditText) findViewById(R.id.txtInputAccess);
                Intent iAccess = new Intent(Configurar.this, MainActivity.class);
                iAccess.putExtra(txtAcces.getText().toString(),true);
                startActivity(iAccess);
            }
        });
    }
}
