package com.linkcea.c4s2_tarea.presenter;

public interface IPetProfilePresenter {

    void obtenerMediosRecientes();

    public void mostrarContactosRV();

}
