package com.linkcea.c4s2_tarea.presenter;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;


import com.google.gson.Gson;
import com.linkcea.c4s2_tarea.fragment.IViewPetProfileFragment;
import com.linkcea.c4s2_tarea.pojo.PetApi;
import com.linkcea.c4s2_tarea.restApi.EndpointsApi;
import com.linkcea.c4s2_tarea.restApi.restAdapter.RestApiAdapter;
import com.linkcea.c4s2_tarea.restApi.restmodel.PetResponse;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PetFragmentProfilePresenter implements IPetProfilePresenter {

    private IViewPetProfileFragment iViewPetProfileFragment;
    private Context context;
    private ArrayList<PetApi> pets;

    public PetFragmentProfilePresenter(IViewPetProfileFragment iViewPetProfileFragment, Context context) {
        this.iViewPetProfileFragment = iViewPetProfileFragment;
        this.context = context;
        //obtenerContactos();
        obtenerMediosRecientes();
    }

    @Override
    public void obtenerMediosRecientes() {

        RestApiAdapter restApiAdapter = new RestApiAdapter();
        //Establecer conexion
        Gson gsonMediaRecent =  restApiAdapter.construirGsonDeserializadorMediaRecent();
        EndpointsApi endpointsApi = restApiAdapter.establecerConexionRestApiInstagram(gsonMediaRecent);
        //Ejecutar la llamada
        Call<PetResponse> petResponseCall = endpointsApi.getRecentMedia();
        petResponseCall.enqueue(new Callback<PetResponse>() {
            @Override
            public void onResponse(Call<PetResponse> call, Response<PetResponse> response) {
                PetResponse petResponse = response.body();
                pets = petResponse.getPets();
                mostrarContactosRV();
            }

            @Override
            public void onFailure(Call<PetResponse> call, Throwable t) {
                Toast.makeText(context, "Algo paso en la conexion, intenta de nuevo", Toast.LENGTH_LONG).show();
                Log.e("FALLO LA CONEXION", t.toString());
            }
        });
    }

    @Override
    public void mostrarContactosRV() {
        iViewPetProfileFragment.inicializarAdaptadorRV(iViewPetProfileFragment.crearAdaptador(pets));
        iViewPetProfileFragment.generarGridLayout();
    }

}
