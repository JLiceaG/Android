package com.linkcea.c4s2_tarea.fragment;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.adapter.PetProfileAdapter;
import com.linkcea.c4s2_tarea.pojo.PetApi;
import com.linkcea.c4s2_tarea.presenter.IPetProfilePresenter;
import com.linkcea.c4s2_tarea.presenter.PetFragmentProfilePresenter;

import java.util.ArrayList;

public class PerfilFragment extends Fragment implements IViewPetProfileFragment {

    private ArrayList<PetApi> pets;
    private RecyclerView rvPetsProfile;
    private IPetProfilePresenter presenter;

    public PerfilFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_perfil, container, false);

        rvPetsProfile = (RecyclerView) v.findViewById(R.id.rvPetsProfile);
        presenter = new PetFragmentProfilePresenter(this, getContext());

        return v;
    }

    @Override
    public PetProfileAdapter crearAdaptador(ArrayList<PetApi> pets) {
        PetProfileAdapter adaptador = new PetProfileAdapter(pets, getActivity()  );
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(PetProfileAdapter adaptador) {
        rvPetsProfile.setAdapter(adaptador);
    }


    @Override
    public void generarGridLayout() {

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        rvPetsProfile.setLayoutManager(gridLayoutManager);
    }
}
