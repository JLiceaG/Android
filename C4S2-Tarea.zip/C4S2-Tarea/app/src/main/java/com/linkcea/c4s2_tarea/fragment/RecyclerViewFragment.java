package com.linkcea.c4s2_tarea.fragment;

import android.app.Activity;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.adapter.PetAdapter;
import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.presenter.IPetPresenter;
import com.linkcea.c4s2_tarea.presenter.PetFragmentPresenter;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment implements IViewPetsFragment{

    private PetAdapter petAdapter;
    private ArrayList<Pet> pets;
    private RecyclerView rvPets;
    private View v;
    private IPetPresenter iPetPresenter;
    private static ArrayList<Pet> favPets;
    private static TextView tvCountLikes;

    public RecyclerViewFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v= inflater.inflate(R.layout.fragment_recyclerview,container, false);
        favPets = new ArrayList<>();
        rvPets = (RecyclerView) v.findViewById(R.id.rvPets);
        tvCountLikes = (TextView) v.findViewById(R.id.tvBonies);
        iPetPresenter = new PetFragmentPresenter(this, getContext(),getActivity());

        return v;
    }

    @Override
    public void generarLayoutManager() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(v.getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvPets.setLayoutManager(linearLayoutManager);
    }

    @Override
    public PetAdapter crearAdaptador(ArrayList<Pet> listMascotas, Activity activity) {
        petAdapter = new PetAdapter(listMascotas, activity, true);
        return petAdapter;
    }

    @Override
    public void inicializarAdaptador(PetAdapter petAdapter) {
        rvPets.setAdapter(petAdapter);
    }


}
