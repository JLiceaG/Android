package com.linkcea.c4s2_tarea.adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.linkcea.c4s2_tarea.db.ConstructorMascota;
import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.R;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;


public class PetAdapter extends RecyclerView.Adapter<PetAdapter.PetViewHolder> {

    private ArrayList<Pet> petsRewarded;
    private ArrayList<Pet> pets;
    private Activity activity;
    private boolean visibleLikeButton;

    public PetAdapter(ArrayList<Pet> pets, Activity activity, boolean visibleLikeButton){
        this.pets = pets;
        this.activity = activity;
        this.petsRewarded = new ArrayList<>();

        try{
        } catch (Exception e){
            Log.e(TAG, "PetAdapter: "  );
        }
        this.visibleLikeButton = visibleLikeButton;
    }

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_pets,
                viewGroup,
                false);

        return new PetViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder petViewHolder, final int position) {
        final Pet petExtraido = pets.get(position);
        final TextView tvCountLikes = petViewHolder.tvBonies;

        if (!petExtraido.getGaleria().isEmpty()){
            petViewHolder.ivPetPicture.setImageResource(petExtraido.getGaleria().get(0).getIdFoto());
        }

        petViewHolder.tvPetName.setText(petExtraido.getName());
        final ConstructorMascota constructorMascota = new ConstructorMascota(activity);
        tvCountLikes.setText(String.valueOf(constructorMascota.getCountLikes(petExtraido.getGaleria().get(0))));
        //petViewHolder.tvBonies.setText(Integer.toString(pet.getBonies()));


        if(visibleLikeButton){
            petViewHolder.ibGiveABonie.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!petsRewarded.contains(petExtraido)){
                        Snackbar.make(v, "Fue agregado a favoritos", Snackbar.LENGTH_SHORT).show();
                        if (!petExtraido.getGaleria().isEmpty()){
                            constructorMascota.putLikeContacto(petExtraido.getGaleria().get(0));
                            tvCountLikes.setText(String.valueOf(constructorMascota.getCountLikes(petExtraido.getGaleria().get(0))));
                        }
                    }else{
                        Toast.makeText(activity, "Ya te gusta " + petExtraido.getName(), Toast.LENGTH_SHORT).show();
                    }
                    //petExtraido.setBonies(petExtraido.getBonies() + 1);
                    //Toast.makeText(activity, "Le diste un huesito a " + pet.getName(),
                            //Toast.LENGTH_SHORT).show();
                    //notifyItemChanged(position);
                }
            });
        } else {
            petViewHolder.ibGiveABonie.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    public static class PetViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPetPicture;
        private ImageButton ibGiveABonie;
        private TextView tvPetName;
        private TextView tvBonies;
        private ImageView ivBonie;


        public PetViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPetPicture = (ImageView) itemView.findViewById(R.id.ivPetPicture);
            ibGiveABonie = (ImageButton) itemView.findViewById(R.id.ibGiveABonie);
            tvPetName = (TextView) itemView.findViewById(R.id.tvPetName);
            tvBonies = (TextView) itemView.findViewById(R.id.tvBonies);
            ivBonie = (ImageView) itemView.findViewById(R.id.ivBones);
        }
    }
}