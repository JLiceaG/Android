package com.linkcea.c4s2_tarea.db;

import android.content.ContentValues;
import android.content.Context;

import com.linkcea.c4s2_tarea.R;
import com.linkcea.c4s2_tarea.pojo.Pet;
import com.linkcea.c4s2_tarea.pojo.PetFoto;

import java.util.ArrayList;


public class ConstructorMascota {

    private static final int LIKE = 1;
    private Context context;
    private ArrayList<Pet> listMascota;

    public ConstructorMascota(Context context) {
        this.context = context;
    }

    public ArrayList<Pet> obtenerDatos() {
        BaseDatos db = new BaseDatos(context);
        insertarMascotas(db);
        return db.obtenerMascotas();
    }

    public void insertarMascotas (BaseDatos db){
        ContentValues contentValuesMascota = new ContentValues();
        ContentValues contentValuesFoto = new ContentValues();
        ContentValues contentValuesLikeFoto = new ContentValues();

        contentValuesMascota.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME, "Pyro");
        db.insertarMascota(contentValuesMascota);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID, 1);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO, R.drawable.pastoraleman);
        db.insertarFoto(contentValuesFoto);


        contentValuesMascota.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME, "Cerberus");
        db.insertarMascota(contentValuesMascota);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID, 2);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO, R.drawable.husky);
        db.insertarFoto(contentValuesFoto);
        contentValuesMascota.clear();
        contentValuesFoto.clear();

        contentValuesMascota.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME, "Yako");
        db.insertarMascota(contentValuesMascota);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID, 3);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO, R.drawable.chihuahua);
        db.insertarFoto(contentValuesFoto);
        contentValuesMascota.clear();
        contentValuesFoto.clear();

        contentValuesMascota.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME, "Revali");
        db.insertarMascota(contentValuesMascota);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID, 4);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO, R.drawable.gato);
        db.insertarFoto(contentValuesFoto);
        contentValuesMascota.clear();
        contentValuesFoto.clear();

        contentValuesMascota.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_NAME, "Astor");
        db.insertarMascota(contentValuesMascota);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_MASCOTA_ID, 5);
        contentValuesFoto.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_DIRFOTO, R.drawable.golden);
        db.insertarFoto(contentValuesFoto);
        contentValuesMascota.clear();
        contentValuesFoto.clear();

        db.close();
    }

    public void putLikeContacto (PetFoto fotoLikeada){
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.DATABASE_TABLE_FOTO_ID, fotoLikeada.getIdMascotaFoto());
        contentValues.put(ConstantesBaseDatos.DATABASE_TABLE_LIKEFOTO_NUMLIKES, LIKE);
        db.insertarLikeFoto(contentValues);
    }

    public int getCountLikes (PetFoto petFoto){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikeMascotaFoto(petFoto);
    }

    public ArrayList<Pet> obtenerMAscotasLikeadas () {
        BaseDatos db = new BaseDatos(context);
        return db.obtenerMascotasLikeadas();
    }
}
