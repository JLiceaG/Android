package com.linkcea.c3s3proyectomascotas;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder>{

    ArrayList<Mascota> mascotas;
    Activity activity;

    public MascotaAdaptador(ArrayList<Mascota> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;

    }

    //Inflar el layout y pasarlo al ViewHolder para que obtenga cada elemento (views)
    @Override
    public MascotaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascota, parent, false);
        return new MascotaViewHolder(v);
    }
    //Asocia cada elemento de la lista con cada View
    @Override
    public void onBindViewHolder(MascotaViewHolder mascotaViewHolder, int position) {
        final Mascota mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());
        mascotaViewHolder.tvName.setText(mascota.getNombre());
        mascotaViewHolder.tvLikes.setText(mascota.getLikes());


        //MENSAJE PARA EL LIKE
        mascotaViewHolder.btnLike.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(activity, "Diste like a " + mascota.getNombre(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent (activity, DetalleMascota.class);
                intent.putExtra("nombre", mascota.getNombre());
                intent.putExtra("likes", mascota.getLikes());
                intent.putExtra("foto",mascota.getFoto());
                activity.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() { //Cantidad de elementos que contiene mi lista de contactos
        return mascotas.size();
    }

    public static class MascotaViewHolder extends RecyclerView.ViewHolder{

        private ImageView imgFoto;
        private TextView tvName;
        private TextView tvLikes;
        private ImageButton btnLike;


        public MascotaViewHolder(View itemView) {
            super(itemView);
            imgFoto= (ImageView) itemView.findViewById(R.id.imgFoto);
            tvName= (TextView) itemView.findViewById(R.id.tvName);
            tvLikes= (TextView) itemView.findViewById(R.id.tvLikes);
            btnLike= (ImageButton) itemView.findViewById(R.id.btnLike);

        }
    }
}
