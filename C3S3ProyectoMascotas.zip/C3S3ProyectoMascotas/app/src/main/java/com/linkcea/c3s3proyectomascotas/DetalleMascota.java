package com.linkcea.c3s3proyectomascotas;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalleMascota extends AppCompatActivity {
    private ImageView ivFoto;
    private TextView tvNombre;
    private TextView tvLike;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_mascota);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBarPass);
        setSupportActionBar(miActionBar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle parametros = getIntent().getExtras();
        //int foto = parametros.getString(getResources().getInteger(1)); //email
        String nombre = parametros.getString(getResources().getString(R.string.pnombre)); //nombre
        String telefono = parametros.getString(getResources().getString(R.string.plikes)); //likes

        ivFoto = (ImageView) findViewById(R.id.ivFotoPass);
        tvNombre = (TextView) findViewById(R.id.tvNamePass);
        tvLike = (TextView) findViewById(R.id.tvLikesPass);

        //ivFoto.setImageResource(foto);
        tvNombre.setText(nombre);
        tvLike.setText(telefono);

        }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if (keyCode == KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(DetalleMascota.this, MainActivity.class);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }
}
