package com.linkcea.c3s3proyectomascotas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Mascota> mascota;
    private RecyclerView listaMascotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);

        listaMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        //Layout Lineal
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listaMascotas.setLayoutManager(llm);
        inicializarListaMascotas();
        inicializaAdaptador();
    }

    public MascotaAdaptador adaptador;
    public void inicializaAdaptador(){
        adaptador = new MascotaAdaptador(mascota, this);
        listaMascotas.setAdapter(adaptador);
    }

    public void inicializarListaMascotas(){
        mascota = new ArrayList<Mascota>();
        mascota.add(new Mascota(R.drawable.pastoraleman,"Pyro", "5"));
        mascota.add(new Mascota (R.drawable.husky,"Cerberus", "3"));
        mascota.add(new Mascota(R.drawable.chihuahua,"Yako", "1"));
        mascota.add(new Mascota(R.drawable.golden,"Dorao", "4"));
        mascota.add(new Mascota(R.drawable.gato,"Pichu", "2"));

    }
    public void irDetalleMascota (View v) {
        Intent intent = new Intent(this, DetalleMascota.class);
        startActivity(intent);

    }

}
