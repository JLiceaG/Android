package com.linkcea.c3s2desarrollandounaaplicacion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botonNext = findViewById(R.id.btnNext);
        botonNext.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                EditText pNombre = (EditText) findViewById(R.id.txtInName);
                EditText pTel = (EditText) findViewById(R.id.txtInTel);
                EditText pEmail = (EditText) findViewById(R.id.txtInEmail);
                EditText pDesc = (EditText) findViewById(R.id.txtInDescComp);
                DatePicker pFecha = (DatePicker) findViewById(R.id.dpBirth);
                String fecha;
                Intent iconf = new Intent(MainActivity.this, Confirmacion.class);
                iconf.putExtra(getResources().getString(R.string.nombrepass), pNombre.getText().toString());
                iconf.putExtra(getResources().getString(R.string.telpass), pTel.getText().toString());
                iconf.putExtra(getResources().getString(R.string.empass), pEmail.getText().toString());
                iconf.putExtra(getResources().getString(R.string.descpass), pDesc.getText().toString());
                fecha = Integer.toString(pFecha.getDayOfMonth()) + "-" + Integer.toString(pFecha.getMonth() + 1) + "-" + Integer.toString(pFecha.getYear());
                iconf.putExtra(getResources().getString(R.string.birthpass), fecha);
                startActivity(iconf);
            }
        });
    }
}
