package com.linkcea.c3s2desarrollandounaaplicacion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Confirmacion extends AppCompatActivity{

    private TextView tvNombre;
    private TextView tvTelefono;
    private TextView tvMail;
    private TextView tvDesripcion;
    private TextView tvFecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar);

        Bundle parametros = getIntent().getExtras();

        String nombre=parametros.getString(getResources().getString(R.string.nombrepass));
        String telefono=parametros.getString(getResources().getString(R.string.telpass));
        String email=parametros.getString(getResources().getString(R.string.empass));
        String descripcion=parametros.getString(getResources().getString(R.string.descpass));
        String fecha=parametros.getString(getResources().getString(R.string.birthpass));

        tvNombre =(TextView) findViewById(R.id.txtNombre);
        tvTelefono =(TextView) findViewById(R.id.txtTelValue);
        tvMail =(TextView) findViewById(R.id.txtEmailValue);
        tvDesripcion =(TextView) findViewById(R.id.txtDescripcionValue);
        tvFecha =(TextView) findViewById(R.id.txtBirthDate);

        tvNombre.setText(nombre);
        tvTelefono.setText(telefono);
        tvMail.setText(email);
        tvDesripcion.setText(descripcion);
        tvFecha.setText(fecha);

        Button botonEditar = findViewById(R.id.btnEdit);
        botonEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
