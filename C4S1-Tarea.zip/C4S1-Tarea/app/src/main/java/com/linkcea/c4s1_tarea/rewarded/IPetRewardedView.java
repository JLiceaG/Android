package com.linkcea.c4s1_tarea.rewarded;

import android.app.Activity;

import com.linkcea.c4s1_tarea.pojo.Pet;
import com.linkcea.c4s1_tarea.adapter.PetAdapter;

import java.util.ArrayList;

public interface IPetRewardedView {

    public void generarLayoutManager();

    public PetAdapter crearAdaptador(ArrayList<Pet> listContactos, Activity activity);

    public void inicializarAdaptador(PetAdapter petAdapter);

    public boolean isEmptyRV(ArrayList<Pet> listMascotasLike);
}
