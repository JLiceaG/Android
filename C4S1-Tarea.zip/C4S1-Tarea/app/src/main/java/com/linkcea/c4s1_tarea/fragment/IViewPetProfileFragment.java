package com.linkcea.c4s1_tarea.fragment;

import com.linkcea.c4s1_tarea.adapter.PetAdapter;
import com.linkcea.c4s1_tarea.adapter.PetProfileAdapter;
import com.linkcea.c4s1_tarea.pojo.Pet;
import com.linkcea.c4s1_tarea.pojo.PetApi;

import java.util.ArrayList;

public interface IViewPetProfileFragment {

    public void generarGridLayout();

    public PetProfileAdapter crearAdaptador(ArrayList<PetApi> pets);

    public void inicializarAdaptadorRV(PetProfileAdapter adaptador);

}
