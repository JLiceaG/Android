package com.linkcea.c4s1_tarea;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.linkcea.c4s1_tarea.R;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Contacto extends AppCompatActivity {

    EditText nombre;
    EditText correo;
    EditText mensaje;
    Session session;
    String contrasena;
    Button botonEnviar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);

        nombre = (EditText) findViewById(R.id.txtInputNombre);
        correo = (EditText) findViewById(R.id.txtInputMail);
        mensaje = (EditText) findViewById(R.id.txtInputMensaje);
        botonEnviar = (Button) findViewById(R.id.btnEnviar);


        botonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarMail();
                Toast.makeText(getBaseContext(),"Comentario enviado", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void enviarMail () {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Properties properties = new Properties();
        properties.put("mail.smtp.host","smtp.googlemail.com");
        properties.put("mail.smtp.socketFactory.port","465");
        properties.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.port","465");

        try {
            session= javax.mail.Session.getDefaultInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("","");
                }
            });
            if (session!=null) {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("jliceag@gmail.com"));
                message.setSubject("Mensaje de "+nombre.getText().toString());
                message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(correo.getText().toString()));
                message.setContent(mensaje.getText().toString(),"text/html; charset=utf-8");
                Transport.send(message);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
