package com.linkcea.c4s1_tarea.presenter;

public interface IPetRewardedPresenter {
    public void obtenerMascotas();
    public void mostrarMascotasRV();
}
