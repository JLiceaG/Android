package com.linkcea.c4s1_tarea.restApi;

public final class ConstantesRestApi {

    public static final String VERSION = "/v1/";
    public static final String URL_BASE = "https://api.instagram.com"+VERSION;
    public static final String ACCESS_TOKEN = "3243626736.2a75fa7.6741d2b7614e45fc81bf69a67351a8d5";
    public static final String KEY_ACCESS_TOKEN = "?access_token=";
    public static final String KEY_MEDIA_RECENT = "users/self/media/recent/";

    public static final String URL_MEDIA_RECENT =URL_BASE+KEY_MEDIA_RECENT+KEY_ACCESS_TOKEN+ACCESS_TOKEN;

}
