package com.linkcea.c4s1_tarea.restApi;

import com.linkcea.c4s1_tarea.restApi.restmodel.PetResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface EndpointsApi {
    @GET(ConstantesRestApi.URL_MEDIA_RECENT)
    Call<PetResponse> getRecentMedia();
}
