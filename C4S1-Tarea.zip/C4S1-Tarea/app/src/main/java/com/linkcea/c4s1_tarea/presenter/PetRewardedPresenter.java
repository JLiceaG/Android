package com.linkcea.c4s1_tarea.presenter;

import android.app.Activity;
import android.content.Context;

import com.linkcea.c4s1_tarea.db.ConstructorMascota;
import com.linkcea.c4s1_tarea.pojo.Pet;
import com.linkcea.c4s1_tarea.rewarded.IPetRewardedView;

import java.util.ArrayList;

public class PetRewardedPresenter implements IPetRewardedPresenter {

    private IPetRewardedView iPetRewardedView;
    private Context context;
    private Activity activity;
    private ArrayList<Pet> listMascota;
    private ConstructorMascota constructorMascota;

    public PetRewardedPresenter(IPetRewardedView iPetRewardedView, Context context, Activity activity) {
        this.iPetRewardedView = iPetRewardedView;
        this.context = context;
        this.activity = activity;
        obtenerMascotas();
    }

    @Override
    public void obtenerMascotas() {
        constructorMascota = new ConstructorMascota(context);
        listMascota = constructorMascota.obtenerMAscotasLikeadas();
        if(!iPetRewardedView.isEmptyRV(listMascota)){
            mostrarMascotasRV();
        }
    }

    @Override
    public void mostrarMascotasRV() {
        iPetRewardedView.inicializarAdaptador(iPetRewardedView.crearAdaptador(listMascota, activity));
        iPetRewardedView.generarLayoutManager();
    }

}
