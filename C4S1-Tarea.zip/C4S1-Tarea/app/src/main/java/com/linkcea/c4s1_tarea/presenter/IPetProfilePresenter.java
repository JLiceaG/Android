package com.linkcea.c4s1_tarea.presenter;

public interface IPetProfilePresenter {

    void obtenerMediosRecientes();

    public void mostrarContactosRV();

}
