package com.linkcea.c4s1_tarea.pojo;

public class PetFoto {

    private int idMascotaFoto;
    private int idMascota;
    private int idFoto;


    private  Pet pet;
    private int likes;

    public PetFoto(Pet pet, int idFoto, int likes) {
        this.pet = pet;
        this.idFoto = idFoto;
        this.likes = likes;
    }

    public PetFoto() {

    }

    public Pet getPet() {
        return pet;
    }

    public void setPet(Pet pet) {
        this.pet = pet;
    }

    public int getIdFoto() {
        return idFoto;
    }

    public void setIdFoto(int idFoto) {
        this.idFoto = idFoto;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getIdMascotaFoto() {
        return idMascotaFoto;
    }

    public void setIdMascotaFoto(int idMascotaFoto) {
        this.idMascotaFoto = idMascotaFoto;
    }

    public int getIdMascota() {
        return idMascota;
    }

    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }
}

