package com.linkcea.c4s1_tarea.restApi.restmodel;

import com.linkcea.c4s1_tarea.pojo.Pet;
import com.linkcea.c4s1_tarea.pojo.PetApi;

import java.util.ArrayList;

public class PetResponse {

    ArrayList<PetApi> pets;

    public ArrayList<PetApi> getPets() {
        return pets;
    }

    public void setPets(ArrayList<PetApi> contactos) {
        this.pets = contactos;
    }



}
