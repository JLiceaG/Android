package com.linkcea.c4s1_tarea.presenter;

import android.app.Activity;
import android.content.Context;

import com.linkcea.c4s1_tarea.db.ConstructorMascota;
import com.linkcea.c4s1_tarea.fragment.IViewPetsFragment;
import com.linkcea.c4s1_tarea.pojo.Pet;

import java.util.ArrayList;

public class PetFragmentPresenter implements IPetPresenter {

    private IViewPetsFragment iViewPetsFragment;
    private Context context;
    private Activity activity;
    private ArrayList<Pet> listMascotas;
    private ConstructorMascota constructorMascota;


    public PetFragmentPresenter(IViewPetsFragment iViewPetsFragment, Context context, Activity activity) {
        this.iViewPetsFragment = iViewPetsFragment;
        this.context = context;
        this.activity = activity;
        obtenerMascotas();
    }


    @Override
    public void obtenerMascotas() {
        constructorMascota = new ConstructorMascota(context);
        listMascotas = constructorMascota.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        iViewPetsFragment.inicializarAdaptador(iViewPetsFragment.crearAdaptador(listMascotas, activity));
        iViewPetsFragment.generarLayoutManager();
    }

}
