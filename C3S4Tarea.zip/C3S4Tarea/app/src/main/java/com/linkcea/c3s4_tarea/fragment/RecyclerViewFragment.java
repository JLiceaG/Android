package com.linkcea.c3s4_tarea.fragment;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.linkcea.c3s4_tarea.Pet;
import com.linkcea.c3s4_tarea.adapter.PetAdapter;
import com.linkcea.c3s4_tarea.R;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment {
    ArrayList<Pet> pets;
    private RecyclerView rvPets;
    private ArrayList<Pet> favPets;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v= inflater.inflate(R.layout.fragment_recyclerview,container, false);

        rvPets = (RecyclerView) v.findViewById(R.id.rvPets);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        rvPets.setLayoutManager(llm);

        inicializarPets();
        inicializarAdaptador();

        return v;
    }


    public void inicializarPets(){
        pets = new ArrayList<Pet>();

        pets.add(new Pet("Pyro", 10, R.drawable.pastoraleman));
        pets.add(new Pet("Cerberus", 7, R.drawable.husky));
        pets.add(new Pet("Yako", 3, R.drawable.chihuahua));
        pets.add(new Pet("Revali", 9, R.drawable.gato));
        pets.add(new Pet("Astor",8, R.drawable.golden));
    }

    public void inicializarAdaptador(){
        PetAdapter adapter = new PetAdapter(pets, getActivity(), true);
        rvPets.setAdapter(adapter);
    }
}
